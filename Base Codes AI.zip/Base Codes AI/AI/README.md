# Artificial-Intelligence-Lab
IIIT Allahabad 
B. Tech. (IT) 
5th Semester 
Artificial Intelligence (IAIN532C)
Lab Assignments
